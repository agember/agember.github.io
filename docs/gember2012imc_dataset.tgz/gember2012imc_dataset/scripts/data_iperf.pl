#!/bin/env perl

use strict;
my $line;
my $id;
my $seenzero;

$id = 0;

while ($line=<STDIN>)
{
    chomp $line;
    if ($line=~m/port 5002/) 
    {
        if ($line=~m/\[\s*(\d+)\]/)
        { $id = $1; }
        next;
    }
    if ($id > 0 && $line=~m/\[\s*$id\]/)
    {
        if ($line=~m/\s+0.0-\s*\d+\.\d+\ssec/)
        { 
            if ($seenzero)
            { next; }
            $seenzero = 1;
        }

        $line=~m/(\d+.\d+)\s(bits|Kbits|Mbits)\/sec/;
        my $bw = $1; #@cols[7];
        my $units = $2; #@cols[8];

        if ($units=~m/^bits/)
        { $bw = $bw / 1000; }
        elsif ($units=~m/^Mbits/)
        { $bw = $bw * 1000; }
        print "$bw\n";
    }
}
