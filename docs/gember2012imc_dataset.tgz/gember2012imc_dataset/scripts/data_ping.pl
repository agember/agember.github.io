#!/bin/env perl

use strict;
my $line;

while ($line=<STDIN>)
{
    chomp $line;
    if ($line=~m/time=(\d+) ms/)
    {
        $line=~m/time=(\d+) ms/;
        my $latency = $1;

        print "$latency\n";
    }
}
